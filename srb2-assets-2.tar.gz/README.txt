SONIC ROBO BLAST 2

Sonic Robo Blast 2 (SRB2) is a 3D Sonic the Hedgehog fangame based on a modified version of Doom Legacy.

LICENSE

The source code for SRB2 is licensed under the GNU General Public License, Version 2. See LICENSE.txt for the full text of this license.

SRB2 uses various third-party libraries, including SDL, SDL Mixer, and their dependencies. See LICENSE-3RD-PARTY.txt for the licenses of these
libraries.

SOURCE CODE

You may obtain the source code for SRB2, including the source code for specific version releases, at the following web sites:

STJr GitLab:
https://git.do.srb2.org/STJr/SRB2

GitHub:
https://github.com/STJr/SRB2

CONTACT

You may contact Sonic Team Junior via the following web sites:

SRB2 Message Board:
https://mb.srb2.org

SRB2 Official Discord:
https://discord.gg/b3BGb8A

Twitter:
https://twitter.com/SonicTeamJr

Facebook:
https://facebook.com/SonicRoboBlast2


COPYRIGHT AND DISCLAIMER

Sonic Team Junior is in no way affiliated with SEGA or Sonic Team. We do not claim ownership of any of SEGA's intellectual property used in SRB2.

Design and content in Sonic Robo Blast 2 is copyright 1998-2022 by Sonic Team Jr. All original material in this game is copyrighted by their respective owners, and no copyright infringement is intended. Sonic Team Jr. is in no way affiliated with Sega or Sonic Team. 

Sonic Robo Blast 2 is not commercial software. If you purchased this game, you have been scammed! Sonic Team Jr.'s staff makes no profit whatsoever (in fact, we lose money). 

This software is provided as-is with no warranty whatsoever.
