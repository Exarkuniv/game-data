Caesar3 DEMO Readme
8/3/98

_______________________________________________________________________
[ To read this file, select Edit/Word Wrap from the menu above ]
TO ORDER: Please call Sierra On-line sales support at 1-800-757-7707
_______________________________________________________________________

TABLE OF CONTENTS

I] MINIMUM REQUIREMENTS
II] HOW TO START THE DEMO
III] HOW TO PLAY THE DEMO 
IV] ASSIGNMENT BRIEFINGS


I] MINIMUM REQUIREMENTS
________________________________________________________________

Windows 95
Pentium 90
16 MB RAM
1MB PCI Video Card, 16 bit
Soundcard with DAC


II] HOW TO START THE DEMO
_______________________________________________________________________

Choose the windows start menu then select programs, sierra, Caesar3, Caesar3Demo.


III] HOW TO PLAY THE DEMO  
_______________________________________________________________________



Welcome to the playable demo of Caesar III. We hope you enjoy the demo. This document will help you 
learn how to use the demo.

If you have played Caesar II, be careful! You may think that you know what to do, but since the underlying 
city model has changed substantially, you may end up in trouble. The game is now a lot more intuitive than 
Caesar II was, so you should quickly learn the changes just by reading the messages and briefings on 
screen. If in doubt, right-click on a structure or piece of land for more information about it.

Caesar III casts you as a trainee governor at the very start of the ancient Roman Empire. Your success will 
lead to promotion and personal financial gains, and could help expand the empire itself. Ultimately, your 
goal is to rise all the way to becoming Caesar, Emperor of Rome.

Each assignment will have specific goals to do with governing a city within a province of the fledgling 
empire. Often, especially early on, you will have to start a new settlement from scratch; later on (not in this 
demo) you will be charged with governing existing cities, which will need you to fix any problems they 
may have.

Governing a city is relatively straightforward, using common sense. You should allocate areas for housing, 
and then provide for the basic needs of the people who come to live in your settlement-food, water, 
security. As the settlement develops into a town, you should add entertainment, temples, health structures, 
government buildings, and more. 

Cities consist of a collection of working buildings. To build a new structure, select a category from the 
panel at the right of the screen, then select the specific structure you would like to build from the available 
choices you will see. Now, move the mouse pointer over the landscape. You will see the structure itself 
where you are able to place the building, otherwise you will see a red diamond, indicating that this 
particular structure may not be placed in that location.

In order for buildings to "work" you should place them sensibly together. This is mainly intuitive, although 
there are a couple of key concepts you should learn:

1)	Road Access: all structures (other than water structures, parks and statues) should be next to a 
road. This does not mean that the building should be surrounded by road, merely that there 
should be some road next to at least some of one of the building's sides.

2)	Labour Access: most structures in Caesar 3 need to employ people to operate them. A new 
structure will send out a citizen to walk along the roads in search of housing; if he walks past 
housing, the structure will know it has physical access to labour. Water structures, such as 
fountains and reservoirs, are the only structures which do NOT need to be connected by road to a 
labour supply.

3)	Insufficient Labour: Even if a structure has access to labour, there may not be enough labour in 
the city for all buildings to work. The computer automatically allocates the available workforce 
to tasks; you can review and change the order in which different categories are assigned labour 
from the Labour Advisor screen. 

You should try to look after your people-make sure that they eat, have jobs, and live in as pleasant 
conditions as possible. Should your city be an undesirable place, few will wish to move in, which could 
hamper your chances of achieving your objectives. Should your city become too desirable, you may find 
problems with too much unemployment, which could lead to crime.

Once your settlement is up and running, you will also be able to interact with the rest of the empire. In this 
demo, that means that you can establish trade routes with other cities. In the full game, you will also be able 
to send armies out to fight enemies of Rome, as well as needing to protect your own cities. From time to 
time, the Emperor may send you requests. Heed these well, lest you enrage him, since his wrath knows no 
equal!

You will be briefed on each assignment, and may receive other instructions part way through. Check your 
messages carefully-they contain useful information. A fanfare indicates the arrival of a new message, for 
you to read when you are ready. There is also plentiful help in the game; wherever you see question mark 
button, click it to access help appropriate to that panel; alternatively, use the Help menu (at the top of the 
screen) to find the subject about which you seek help.

You can right-click (click with your right mouse button) on any building or piece of landscape in the game. 
This will bring up a panel with some current information; sometimes an explanation of why the structure is 
not operating, or how efficiently it is operating, or what a house needs if it is to evolve into a more 
desirable dwelling. These panels also allow you to access help. This is an important source of information 
for you; if in doubt, right-click on a building!!

You can also right click on the people inhabiting your city. Click at their feet rather than their upper body. 
The people will chat to you about various things; often, they will provide you with useful information about 
the status of your city. For example, if they complain of boredom, you may wish to increase the 
entertainment facilities you offer. Sometimes, they will have nothing useful to say, but will simply pass the 
time of day with you, idly chatting away about their own lives. Note that in this demo version, very little of 
their "chat" has been included as voice; the full game will have voices for all their chatter.






So now I've played the demo, what will the full game add?


The full game of Caesar III adds substantially to what is in this playable demo.

Career Path
The full game allows you to play out a whole career, involving many assignments. As you achieve one set 
of objectives, you will be offered a choice of new assignments. Eventually, you could be promoted to 
Caesar, Emperor of Rome.

Construction Kit
Once you have played through the career campaign, or at any time, you can select one of a wide selection 
of maps, and simply build a city there, with no objectives. You can choose to build almost anywhere within 
the Empire map, with differing playing conditions in different regions.

New Terrain and Larger Maps
The full game will feature terrain of varying height, with hills and plateaux. This will affect gameplay as 
well as making the maps more interesting to look at. There will be several different terrain sets, so that the 
landscape will look quite different depending on where you are. This will also affect gameplay, so the game 
will play differently if you are in the desert than it will if you are in Northern Europe. The maps that you 
have seen in the demo are fairly small; in the full game there will be a variety of map sizes, many very 
much larger than those in the demo.

Combat
You will be able to choose between cities in more dangerous or more peaceful parts of the empire. In the 
more dangerous parts, you will need to defend your city against agressors. The enemy may be local natives, 
upset with the intrusion of Romans into their lands, or a powerful army led by Hannibal, for example. You 
will be able to build walls for protection, and towers which will send out patrols along the walls. You may 
also build forts, each of which will generate one cohort; you may then move these cohorts around the map, 
and choose different formations for them. We are hoping to include naval combat in the game, too, though 
we don't promise anything!!

Boats and Bridges
There will be two types of bridge you can build, enabling your city to expand onto parts of the map 
otherwise inaccessible. You will also be able to set up sea trade routes, and build thriving ports to support 
your developing city.

Empire
Interaction with the rest of the empire is substantially increased compared with Caesar II. You will need to 
be truly wise and politically astute if you are to gain the ultimate promotion.

Many, many more structures
The demo barely scratches the surface of the housing levels available; you will be able to build yourself a 
personal home in the full game, with several to choose from depending on your own financial 
circumstances. You will also be able to build a coliseum and lion house, or even an enormous Circus 
Maximus, to hold chariot races to delight your citizens. There are many more crops and products available, 
walls, towers, gatehouses, forts, statues, large temples, oracles, educational structures, health buildings, and 
more.

And of course, there will be more music, speech, sound effects, and movie clips.

We are also still very much working on balancing the game model and improving the interface further. 

Suggestions are always welcome; you can find out more and make those suggestions to us via our website:
	http:/www.sierrastudios.com



IV] ASSIGNMENT BRIEFINGS
________________________________________________________________

Caesar 3 Demo: Assignment One


Note: 	This is one of two training Assignments for the demo of Caesar 3. The text for these briefings is 
longer than usual for Assignments, and so is also available as a text document in the Caesar 3 
folder, so those of you who wish to can print it out. You will also be able to access this screen at 
any time during the game. We recommend reading the Read Me document also if you find the demo 
difficult, or if you  have any questions about it. 


Let your Governorial training begin!

First, you must learn the basics of constructing Roman settlements.
Build areas of housing, and you'll soon see people move in to your city. 
Right click on them, and they'll give you important information about your city. 

If you right-click on any building, you'll see a panel describing that building, with a Help button you can 
use to find out more about how the structure works. 

 Paths
You can click and drag the mouse to build lengths of path at once
Plan paths carefully, with as few intersections as possible, to ensure people will walk where you want them 
to. At every intersection, walkers must choose which way to go. Every intersection lessens your control 
over their actual routes



Message to be delivered once fire has broken out:

To protect against fire, build a Prefecture (now available) near your housing. The Prefecture sends a citizen 
to walk around and see if he can find access to labour. Once he walks past some housing, the Prefecture has 
access. Then, it can send Prefects out on patrol.
When the Prefect discovers a fire in his area, he moves to douse the fire with buckets of water.

 Once back on normal patrol, the Prefect inspects buildings on his route for fire hazards, reducing their risk 
of catching fire.
Prefects can provide their service to any building within 2 spaces of the road.

Messages
If you hear a fanfare, a message has arrived for you. To read a message, click on the message button.
Extremely urgent messages (like this one) are automatically shown to you, and are also stored with your 
other messages.

Markets
You can now also build Markets. Citizens buy food and other goods at their local Market. Once it has 
enough employees, it generates Market Traders, who walk the roads near the Market. As the trader passes a 
house, the house knows that it has access to a Market.
     
If you make a mistake, there is an undo button at the bottom of the side-panel.



	Message to be delivered once a structure has collapsed:

Although Roman architecture was very advanced, their buildings fell down quite often.

To prevent this happening in your cities, build an Engineer Post. This works the same way as the 
Prefecture, and will send Engineers to patrol your roads and repair any damage found.

You can now build a Senate. There is only ever one in any city. The Senate employs tax collectors, if it has 
access to labour; these walk through the settlement and collect taxes from all houses they pass.
Any people sitting on the steps of the building are unemployed. The more people you see, the more 
unemployment you have.
You may see the paths near the Senate change into paved roads. As an area becomes nicer its citizens 
automatically upgrade their paths into roads.

You can now build a Senate. There is only ever one in any city. The Senate employs tax collectors, if it has 
access to labour; these walk through the settlement and collect taxes from all houses they pass.

			Message to be delivered once the population reaches 120
Pleasing the Gods

Temples
Your citizens are religious, and like Temples near their housing. You must dedicate every Temple to one of 
five gods: Venus, goddess of love; Mercury, god of transport and commerce; Mars, god of War; Ceres, god 
of farming; or Neptune, god of the sea.
     
Try to build an equal number of Temples to each god. They are all jealous, and may become angry with 
you if they feel unfairly treated. They can also become angry if they feel your city is large enough that there 
should be more Temples altogether, so treat them carefully.


Caesar 3 Demo: Assignment 2


Your priorities should be security, housing, food, and water, in that order. Without housing and food, new 
immigrants will not move in to your city.  

Rome now wishes your city to grow food. 
Build a farm on fertile land - look for the yellow tufts that indicate this. Connect it to housing with a path. 
If the housing is too far away, the farm will not get access to labour.
Also build a Granary near to the farm, and make sure it has access to labour.   

When the wheat is ripe, a cart will carry it to the Granary. Gradually the Granary will fill up. The fewer 
empty windows you can see, the fuller the Granary is.               


			Message to be delivered once the granary has wheat stored.

Providing Water
Well done! Your farms are up and running, and your people have food. Now it's time to expand your 
settlement.

Water
Build a Reservoir adjacent to water. Although the Reservoir needs people they do not need road access to 
it. It will fill with water if it has labour and is next to water.
      
Build a Fountain reasonably close to the Reservoir. It will fill up with water if the Reservoir is blue, unless 
there is a shortage of people.
To build a second Reservoir, click on the first one. Hold the mouse button down and 'drag' the cursor to the 
desired location. You'll see a second Reservoir, connected to the original one by an Aqueduct. 
    
Your citizens much prefer to have a Fountain for their water than a Well.  Fountains cover a wider area 
then wells.

 There are lots of overlay reports to help you manage your city. The game continues running while overlays 
are displayed. When using an overlay, right click to see the whole city. Leave your pointer over part of the 
map, and text will explain what it means for that overlay.




			Message to be delivered once the population reaches 250
Growing Your City
Now you can build even more buildings. 

Bath houses need to be in range of a Reservoir, and have access to labour. 

Gardens make an area more desirable.
    
 Theatres are a popular entertainment venue, but they need actors to perform there. Build an Actors' Colony 
to supply them.   Don't forget to build new farms before you run out of food! 

 


			


				Message to be delivered once the population reaches 450
Taxes and Industry

Money
Building and running cities costs money. Rome gives you enough denarii to get started - but it won't be 
enough to complete your assignment. 
Taxes are your major source of income. Eventually, your city will grow beyond the Senate's tax collector 
routes. Build Forums as bases for additional tax inspectors in other parts of your town. 
	
Nicer houses pay more in taxes.
	
Advisors 
Click the Senate button to consult the helpful advisors who help you manage your city. The Chief Advisor 
summarises your whole city, highlighting areas which need your attention. Your Labour Advisor lets you 
change the allocation of labour, or the wage rate your city pays. Visit them all, just to see what is there. 
	
Industry
Now build a Warehouse and Clay Pit, close to water. Connect them to housing as usual, and before long a 
cart will take clay to the Warehouse.  You can also build a Pottery Workshop, to turn clay into pottery. 
When the pottery is ready, a cart takes it to the nearest Warehouse. From there, Market traders will take it if 
there is demand for it in your town. Higher-level housing demands pottery. Build two Pottery Workshops 
to use all of the clay your Clay Pit can produce.

				
Message to be delivered once 3 units of pottery is in the warehouse

Trading with the Empire

Well done! You now have a successful industry in your city. Now you can turn that into cash.

Trade
Trade can be both a major source of income for a city, and a source of desired goods. Click the Empire 
Map button to see a map of the Roman Empire and its surroundings.

Right now, Rome hardly has any empire at all; your success will help it to grow later. But you will see a 
few cities. The city with a black and gold flag is yours; the city with a red flag is one happy to trade with 
you. Click on it to see which products it is prepared to buy from you or sell to you. Click to open a trade 
route (which will cost some money). 

Now, go to your Trade Advisor.
Click on the pots to see how many you have stored at your Warehouse. Click on the 'not trading' button, 
and it will change to 'Export Over' and some arrows; click on the arrows until it says 'Export Over 2'.

This authorizes the sale of any pottery in your  Warehouses in excess of 2 tonnes. Exit to the main game 
now, and before long you will see a donkey train move through your city. If you have more than 2 tonnes 
of pottery in your Warehouse, it will stop and remove it, paying you at the same time. Your first export 
sale!

You can now expand your city further, with income from taxes and pottery sales financing your growth.



Good Luck!  You're sure to be a wonderful governor. Rome is counting on you. May the gods smile upon 
you.





